import React from 'react'
import Ben from "./Coming.png"

function ComBennr() {
  return (
    <>
      <img style={{width:"100%",height:"auto"}} src={Ben} alt="" />
    </>
  )
}

export default ComBennr
