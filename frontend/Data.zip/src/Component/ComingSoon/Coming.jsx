import React from "react";
import Nav from "../Nav/Nav";
import ComBenner from "./ComBennr";

function Coming() {
  return (
    <>
      {/* <Nav /> */}
      <ComBenner />
    </>
  );
}

export default Coming;
