import React from "react";
import Nav from "../Nav/Nav";
import ComBenner from "./ComBennr";
import { Helmet } from "react-helmet";

function Coming() {
 
  return (
    <>
      {/* <Helmet>
        <title>Comin Soon</title>
        <meta name="title" content="Comin Soon"
          data-rh="true" />
        <meta name="description"
          content="Comin Soon"
          data-rh="true" />
        <meta property="og:type" content="Comin Soon" />
        <meta property="og:url" content="https://www.gujaratvandan.com/" data-rh="true" />
        <meta property="og:title" content="Comin Soon"
          data-rh="true" />
        <meta property="og:description"
          content="Comin Soon"
          data-rh="true" />
        <meta property="og:image" content="Comin Soon" data-rh="true" />
        <meta name="image" content="Comin Soon" data-rh="true" />
        <meta property="twitter:card" content="summary_large_image" data-rh="true" />
        <meta property="twitter:url" content="https://www.gujaratvandan.com/" data-rh="true" />
        <meta property="twitter:title"
          content="Comin Soon" />
        <meta property="twitter:description"
          content="Comin Soon"
          data-rh="true" />
        <meta property="twitter:image" content="https://secretseventeen.com/Media/icon.png" data-rh="true" />
      </Helmet> */}
      {/* <Nav /> */}
      <MetaDecorator  description={"Coming Soon"}
        title={"Coming Soon"}
        imageUrl={"Coming Soon"}
        imageAlt={"Coming Soon"}
        link={"Coming Soon"}/>
      <ComBenner />
    </>
  );
}

export default Coming;
