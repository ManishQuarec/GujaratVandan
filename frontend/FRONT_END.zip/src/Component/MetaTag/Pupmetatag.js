import React from 'react'

function Pupmetatag() {
  return (
    <div>Pupmetatag</div>
  )
}

export default Pupmetatag