import React from 'react'
import MetaDecorator from '../MetaTag/Metatag'

function News(data) {
    console.warn("news");
  return (
    <>
    news
    </>
  )
}

export default News